"""
Ma'lumotlar bazasi modellari.
Master § 53: Versioning — har bir report qaysi versiyada yaratilganini saqlaydi.
"""
from sqlalchemy import BigInteger, String, JSON, DateTime, Boolean, Integer, func
from sqlalchemy.orm import Mapped, mapped_column
from backend.db import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)  # telegram id
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    first_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    created_at: Mapped["DateTime"] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class TestResult(Base):
    __tablename__ = "test_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    stage: Mapped[str] = mapped_column(String(16))  # "stage1" | "stage2"
    answers: Mapped[dict] = mapped_column(JSON)
    profile: Mapped[dict] = mapped_column(JSON)
    roadmap: Mapped[dict] = mapped_column(JSON)
    ai_explanation: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    versions: Mapped[dict] = mapped_column(JSON)
    paid: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped["DateTime"] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    stage1_result_id: Mapped[int] = mapped_column(BigInteger, index=True)
    provider: Mapped[str] = mapped_column(String(32))  # click | stars
    amount_uzs: Mapped[int] = mapped_column(BigInteger)
    external_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    status: Mapped[str] = mapped_column(String(16))  # pending | paid | failed | refunded
    raw: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped["DateTime"] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )