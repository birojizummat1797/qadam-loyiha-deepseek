"""
QADAM Telegram Bot — webhook mode (Render uchun).
Master § 11: Bot = orchestration va notification layer.
"""
import os
import asyncio
from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    Message, InlineKeyboardMarkup, InlineKeyboardButton,
    WebAppInfo, MenuButtonWebApp, BotCommand,
)
from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application
from dotenv import load_dotenv

from bot.handlers.payment import router as payment_router

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://qadam.uz")
WEBHOOK_BASE = os.getenv("WEBHOOK_BASE", "http://localhost:8080")
WEBHOOK_PATH = "/webhook"
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "qadam-secret")
WEBHOOK_URL = f"{WEBHOOK_BASE}{WEBHOOK_PATH}"

bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()
dp.include_router(payment_router)


@dp.message(CommandStart())
async def cmd_start(m: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🚀 Testni boshlash", web_app=WebAppInfo(url=WEBAPP_URL))
    ]])
    await m.answer(
        f"Assalomu alaykum, <b>{m.from_user.first_name}</b>!\n\n"
        "Men — <b>QADAM</b>.\n"
        "Sizga o'zingizga mos kasb va sohani topishga yordam beraman.\n\n"
        "⚡ <b>Tezkor tahlil</b> — 3 daqiqa, bepul\n"
        "🎯 <b>Chuqur tahlil</b> — Fit + Readiness + Roadmap + PDF\n\n"
        "Boshlash uchun tugmani bosing:",
        reply_markup=kb,
    )


@dp.message(Command("help"))
async def cmd_help(m: Message):
    await m.answer(
        "<b>QADAM yordam</b>\n\n"
        "/start — boshlash\n"
        "/help — yordam\n\n"
        "Savollar: @qadam_support"
    )


@dp.message(F.web_app_data)
async def webapp_data(m: Message):
    await m.answer("✅ Qabul qilindi.")


async def health(request):
    return web.json_response({"ok": True, "service": "qadam-bot"})


async def on_startup(bot: Bot):
    await bot.set_webhook(
        WEBHOOK_URL,
        secret_token=WEBHOOK_SECRET,
        drop_pending_updates=True,
        allowed_updates=["message", "callback_query", "pre_checkout_query"],
    )
    await bot.set_chat_menu_button(
        menu_button=MenuButtonWebApp(text="QADAM", web_app=WebAppInfo(url=WEBAPP_URL))
    )
    await bot.set_my_commands([
        BotCommand(command="start", description="Boshlash"),
        BotCommand(command="help", description="Yordam"),
    ])


async def on_shutdown(bot: Bot):
    await bot.delete_webhook()


def main():
    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)

    app = web.Application()
    app.router.add_get("/health", health)
    SimpleRequestHandler(
        dispatcher=dp, bot=bot, secret_token=WEBHOOK_SECRET
    ).register(app, path=WEBHOOK_PATH)
    setup_application(app, dp, bot=bot)

    port = int(os.getenv("PORT", 8080))
    web.run_app(app, host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()